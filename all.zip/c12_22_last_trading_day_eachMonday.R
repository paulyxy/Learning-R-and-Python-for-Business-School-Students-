 x<-url("http://canisius.edu/~yany/RData/tradingDaysM.RData")
 load(x)





