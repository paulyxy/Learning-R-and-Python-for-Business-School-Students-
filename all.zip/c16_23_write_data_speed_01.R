n<-500000
a<-rnorm(n)
b<-brnorm(n)
c<-pnorm(n)
x<-data.frame(x1=a,x2=b,x3=c)
write.table(x,file="c:/temp/temp.csv",sep=",",col.names=NA)
cat("first summary of x\n")
summary(x)
y<-read.table("c:/temp/temp.csv",header=TRUE,sep=",",row.names=1)
save(x,file="c:/temp/temp.binary")# write binary
rm(x)
load("c:/temp/temp.binary")
cat("2nd summary of x\n")
summary(x)

