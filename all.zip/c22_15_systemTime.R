n<-1e5
system.time(mean(rnorm(n)))
#
n<-1e8
system.time(mean(rnorm(n)))


