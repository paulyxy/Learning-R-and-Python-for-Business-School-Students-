 x<-2017
 y<-"C"
 z<-data.frame(x,y)
z

