


x <-read.table('ibm.csv',sep=',',header=T) # relative path

x[2,1]