 x<-1:30
 y<-rev(x)
 z<-cbind(x,y)
 write.csv(z,"c:/temp/t.csv",quote=F,row.names=F)