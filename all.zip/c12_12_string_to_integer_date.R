x<-"2017-01-31"
 y<-substr(x,1,4)
 m<-substr(x,6,7)
 d<-substr(x,9,10)
 date<-as.integer(paste(y,m,d,sep=""))
 date
typeof(date)

