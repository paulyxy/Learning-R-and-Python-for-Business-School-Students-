path<-"http://canisius.edu/~yany/RData/"
dataSet<-"TORQct"
link<-paste(path,dataSet,".RData",sep='')
load(url(link))
 head(.TORQct)

