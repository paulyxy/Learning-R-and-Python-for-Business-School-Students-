 require(XLConnect)
 x<- loadWorkbook("test.xlsx", create = TRUE)


 createSheet(x, name = "mySheet")
 writeWorksheet(wb, ChickWeight, sheet = "chickSheet", startRow = 3, startCol = 4)
 saveWorkbook(wb)


