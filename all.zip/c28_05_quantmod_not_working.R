require(quantmod)
getSymbols('ibm',src='yahoo')


