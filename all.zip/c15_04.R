
 library(xts) 
 data(sample_matrix) 
 typeof(sample_matrix)
 x<- data.frame(sample_matrix)
 typeof(x)
