path<-"http://canisius.edu/~yany/RData/ffcMonthly.RData"
load(url(path))
 head(.ffcMonthly)
 