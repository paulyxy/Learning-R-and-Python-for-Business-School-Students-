 x<-"2018-01-31"
 dd<-as.integer(gsub("-","",x))
 typeof(dd)
 dd