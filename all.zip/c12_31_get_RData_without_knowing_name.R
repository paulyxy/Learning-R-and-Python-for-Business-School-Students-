

 con<-url("http://canisius.edu/~yany/RData/ffc4monthly.RData")
 x<-load(con)
 y<-eval(parse(text=x)) 


