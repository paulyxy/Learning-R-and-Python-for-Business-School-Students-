set.seed(123)
mu<-0.25
std<-0.3
n<-100
x<-rnorm(n,mu,std)
head(x)