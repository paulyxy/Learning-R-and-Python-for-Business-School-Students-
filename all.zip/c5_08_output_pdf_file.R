 pdf("c:/temp/t.pdf")
 plot(sin,-pi,pi)
 dev.off()



