 con<-url("http://canisius.edu/~yany/RData/yanRData.RData")
 x<-load(con)
 print(x)

