 ticker<-"MSFT"
 path<-"http://finance.google.com/finance/historical?q=NYSE:"
 a<-paste(path,ticker,"&output=csv",sep='')
 x<-read.csv(a)
 #write.csv(x,file='msft.csv',quote=F,row.names=F)


