library(tm)
data("crude")
x<- as.matrix(TermDocumentMatrix(crude))
final<- data.frame(ST = rownames(x),Freq = rowSums(x),row.names=NULL)
head(final)
final2<-final[order(final[,2],decreasing =TRUE),]
head(final2)
