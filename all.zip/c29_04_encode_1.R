encode_1<-function(text,shift){
   #text<-gsub(' ','',text)
   ciphertxt<-''
   for(i in 1:nchar(text)){
       for(j in 1:26){
            if(tolower(substr(text,i,i))==letters[j]){
               k<-(j+shift)%%26
               if(k==0)k=26
               ciphertxt<-paste(ciphertxt,letters[k],sep='');break
            }
        }
    }
    return(ciphertxt)
}


