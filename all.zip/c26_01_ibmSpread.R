
a<-"http://canisius.edu/~yany/data/ibmDaily.csv" 
x<-read.csv(a) 
head(x,2)
p<-x$Adj.Close
deltaP<-diff(p)
n<-length(deltaP)
covP<-cov(deltaP[1:(n-1)],deltaP[2:n])
covP
2*sqrt(-covP)

