x<-c(1990,0.01,1991,0.04)
y<-matrix(x,2,2,byrow=T)
z<-data.frame("ibm",y)
colnames(z)<-c("ticker","year","ret")
z

class(z)
