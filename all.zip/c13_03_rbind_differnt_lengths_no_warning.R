
n<-5
x<-c(1:(2*n))
y<-c(1:n)
z<-rbind(x,y)
z
