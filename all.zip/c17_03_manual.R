 library(XLConnect)
 vignette("XLConnect")



