x<-"    This is a dog.   "
y<-gsub("^ *","",x)
z<-gsub(" *$","",y)
z