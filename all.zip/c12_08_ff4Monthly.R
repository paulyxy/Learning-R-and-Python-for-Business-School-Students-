
dataSet<-"ff5Monthly"
#
path<-"http://canisius.edu/~yany/RData/"
con<-paste(path,dataSet,".RData",sep='')
load(url(con))
close(con)
head(.ff5Monthly)

