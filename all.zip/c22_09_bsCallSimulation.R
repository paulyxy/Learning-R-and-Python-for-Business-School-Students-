bsCallSimulation<-function(s,x,T,r,sigma,n=100){
    temp1<-(r-sigma*sigma/2.0)*T
    temp2<-sigma*rnorm(n)*sqrt(T)
    ST<-s*exp(temp1 + temp2)
    payoff<-((ST-x) + abs(ST-x))/2
    final<-mean(payoff)*exp(-r*T)
    return(final)
}


