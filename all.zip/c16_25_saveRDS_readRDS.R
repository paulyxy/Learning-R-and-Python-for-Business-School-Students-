set.seed(123)
x<-rnorm(5000)
head(x,3)
saveRDS(x,"c:/temp/myData.rds")
rm(x)
y<-readRDS("c:/temp/myData.rds")
head(y,3)



