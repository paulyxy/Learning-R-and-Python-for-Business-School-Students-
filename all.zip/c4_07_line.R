


x<-1:10
y<-x*0+6

plot(x,y,type='l')