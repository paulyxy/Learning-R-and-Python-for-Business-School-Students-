

ticker<-"AAA"
set.seed(123)
n<-10
today<-Sys.Date()
beg<-today-9
ret<-runif(n)
ddate<-seq(beg,today,1)
final<-data.frame(ticker,ddate,ret)
colnames(final)<-c("TICKER","DATE","RETURN")