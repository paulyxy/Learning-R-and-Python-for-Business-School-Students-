
path<-"http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/"
name<-"F-F_Research_Data_Factors_CSV.zip"
loc<-paste(path,name,sep='')
download.file(loc,"c:/temp/ffMonthly.zip")



