x<-2:100
save(x,file="c:/temp/test.Rdata")
