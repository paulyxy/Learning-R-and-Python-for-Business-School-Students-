data(sleep)
head(sleep)

oneway.test(extra ~ group, data = sleep)