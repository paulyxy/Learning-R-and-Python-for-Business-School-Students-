googleDailyRet<-function(ticker){
today<-Sys.Date()
today.y <- as.numeric(strsplit(as.character(today), "-", )[[1]][1])
today.m <- as.numeric(strsplit(as.character(today), "-", )[[1]][2])
today.d <- as.numeric(strsplit(as.character(today), "-", )[[1]][3])
to.m<-month.abb[today.m]
t1<-"http://finance.google.com/finance/historical?q="
t2<-paste(t1,ticker,sep='')
t3<-paste(t2, "&startdate=Jan+01,+1970&enddate=",to.m,sep='')
t4<-paste(t3, "+",today.d,",+",today.y,"&output=csv",sep='')
x<-read.csv(t4,header=T)
n<-nrow(x)
dd<-Sys.Date()
for(i in 1:n){
tt<-toString(x[i,1])
dd[i]<-as.Date(tt,"%d-%b-%y")
}
p<-x[,5]
ret<-(p[1:(n-1)]-p[2:n])/p[2:n]
d<-data.frame(dd[1:(n-1)],x[1:(n-1),5],ret)
colnames(d)<-c('Date','Price','Ret')
return(d)
}