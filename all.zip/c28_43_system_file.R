library(XML)
f = system.file("exampleData","mtcars.xml",package="XML")

