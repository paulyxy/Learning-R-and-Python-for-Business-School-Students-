


x<-50:1
write.table(x,'c:/temp/test.txt')