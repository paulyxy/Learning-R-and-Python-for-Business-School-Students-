in.file<-file("c:/temp/test.bin","rb") 
readBin(in.file,integer(),size=4,endian='big')
close(in.file)

in.file<-file("c:/temp/test.bin","rb") 
readBin(in.file,integer(),size=4,endian='little')
close(in.file)

