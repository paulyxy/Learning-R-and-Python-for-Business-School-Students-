> x<-1:10
> y<-paste("data",1:5,sep='')
> x
 [1]  1  2  3  4  5  6  7  8  9 10
> y
[1] "data1" "data2" "data3" "data4" "data5"
> z<-data.frame(x,y)
> z
    x     y
1   1 data1
2   2 data2
3   3 data3
4   4 data4
5   5 data5
6   6 data1
7   7 data2
8   8 data3
9   9 data4
10 10 data5

colnames(z)<-c("ID","DATA")
