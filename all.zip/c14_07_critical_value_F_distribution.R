
alpha<-0.05
d1<-499
d2<-999
qf(1-alpha, df1=d1, df2=d2) 
