x<-read.csv("http://canisius.edu/~yany/data/ibmMonthly.csv",header=T)
n<-nrow(x)
p<-x[,6]
ret<-p[2:n]/p[1:(n-1)]-1
ibm<-data.frame(as.Date(x[2:n,1]),ret)
colnames(ibm)<-c("DATE","RET_IBM")
y<-read.csv("http://canisius.edu/~yany/data/wmtMonthly.csv",header=T)
p2<-y[,6]
n2<-nrow(y)
ret2<-p2[2:n2]/p2[1:(n2-1)]-1
wmt<-data.frame(as.Date(y[2:n2,1]),ret2)
colnames(wmt)<-c("DATE","RET_WMT")
final<-merge(ibm,wmt)
dim(final)
head(final)




t.test(final$RET_IBM,final$RET_WMT)

