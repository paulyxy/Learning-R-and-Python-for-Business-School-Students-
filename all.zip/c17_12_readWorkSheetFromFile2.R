
library(XLConnect)
f<-system.file("demoFiles/multiregion.xlsx",package="XLConnect")
x<- readWorksheetFromFile(f,sheet=1,header=TRUE,startCol=2, startRow=2,endCol=3,endRow=9)
