library(XLConnect)
 f<- system.file("demoFiles/mtcars.xlsx",package ="XLConnect")
f2<-loadWorkbook(f)


 name<- getTables(f2, sheet = "mtcars_table")
 x<-readTable(f2,sheet="mtcars_table",table=name)


 head(x)
mpg cyl disp hp drat wt qsec vs am gear carb
1 21.0 6 160 110 3.90 2.620 16.46 0 1 4 4
2 21.0 6 160 110 3.90 2.875 17.02 0 1 4 4
3 22.8 4 108 93 3.85 2.320 18.61 1 1 4 1
4 21.4 6 258 110 3.08 3.215 19.44 1 0 3 1
5 18.7 8 360 175 3.15 3.440 17.02 0 0 3 2
