x<-1:50
y<-matrix(x,10,5)
write.csv(y, "clipboard",quote=F,row.names=F)

