library(quantmod)
x<-viewFin(getFin("IBM",auto.assign=FALSE),"BS","A")
head(x)
