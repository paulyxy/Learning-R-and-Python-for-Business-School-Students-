  > x<-read.csv("http://canisius.edu/~yany/ibm.csv",header=T)
> n<-nrow(x)
> p<-x$Adj.Close
> ret<-p[2:n]/p[1:(n-1)]-1
> head(ret,2)
[1] -0.009225851 -0.007779961




