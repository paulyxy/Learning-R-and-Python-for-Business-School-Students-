library("xlsx")
outFile<-'c://temp/ff3Monthly.xlsx'
x<-read.csv('http://datayyy.com/data_csv/ff3Monthly.csv')
write.xlsx(x, outFile, sheetName = "ff3",
col.names = TRUE, row.names = F, append = FALSE)








write.xlsx(USArrests, file = "myworkbook.xlsx",
      sheetName = "USA-ARRESTS", append = FALSE)


write.xlsx2(x, file, sheetName = "Sheet1",
  col.names = TRUE, row.names = TRUE, append = FALSE)


write.xlsx(x, file, sheetName = "Sheet1", 
  col.names = TRUE, row.names = TRUE, append = FALSE)

write.xlsx2(x, file, sheetName = "Sheet1",
  col.names = TRUE, row.names = TRUE, append = FALSE)