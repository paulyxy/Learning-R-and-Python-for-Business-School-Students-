 x<-1:5000
 save(x,file="c:/temp/test.RData")

