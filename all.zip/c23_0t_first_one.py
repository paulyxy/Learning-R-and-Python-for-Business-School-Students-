# -*- coding: utf-8 -*-
"""
Created on Fri Nov 20 08:22:01 2020

@author: pyan
"""


import numpy as np
import pandas as pd

np.random.seed(123)
x=pd.Series([1, 5,2, np.nan,-7, 10,np.nan])
dates = pd.date_range('20200101', periods=7)
b=pd.DataFrame(np.random.randn(7, 4), index=dates, columns=list('xyAB'))




# why it sedond time, the output is the same???
print(pd.DataFrame(np.random.randn(7, 4), index=dates, columns=list('xyAB')))


