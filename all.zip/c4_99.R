
# c4  page 


con<-url("http://canisius.edu/~yany/RData/ffMmonthly.RData")
load(con)
head(.ffMonthly)







