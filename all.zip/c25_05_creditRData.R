 path<-"http://canisius.edu/~yany/RData/"
 dataSet<-"credit"
 link<-paste(path,dataSet,".RData",sep='')
 load(url(link))
 rm(path,dataSet,link)
 ls()
