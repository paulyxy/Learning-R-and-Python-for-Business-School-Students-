library(stockPortfolio)
data(stock94)


