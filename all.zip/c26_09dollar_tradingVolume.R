
year<-2000
a<-"http://canisius.edu/~yany/data/ibmMonthly.csv" 
x<-read.csv(a) 
dim(x)
x[,8]<-x$Adj.Close*x$Volume
colnames(x)<-c(colnames(x)[1:7],"DollarVolume")
head(x,3)









