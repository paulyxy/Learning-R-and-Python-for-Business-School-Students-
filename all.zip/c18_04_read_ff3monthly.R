path<-"http://canisius.edu/~yany/RData/ff3monthly.RData"
load(url(path))
head(.ff3monthly)
