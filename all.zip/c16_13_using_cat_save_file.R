cat("1 3 4 5","7 17 6 1",file="c:/temp/test.txt",seq="\n")
cat(file="c:/temp/test2.txt","123456","987654",sep="\n")