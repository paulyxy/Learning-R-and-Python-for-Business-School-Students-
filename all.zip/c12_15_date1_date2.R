


 d1<-as.Date("20170101",format="%Y%m%d")
 d2<-as.Date("20181231",format="%Y%m%d")
 days<-seq(d1,d2,by=1)
 length(days)
 head(days)


