asianCallAveragePrice<-function(S,r,T,n_steps,sigma,x,n_trial){
     payoff<-payoff<-rep(0,time=n_trial) # initialization
     for(i in 1:n_trial){
        Saverage<- mean(ST_path_f(S,r,T,n_steps,sigma))
        payoff[i]<-max(Saverage-x,0)
    }
    return(mean(payoff)*exp(-r*T))
}


set.seed(12345)
asianCallAveragePrice(50,0.1,1,1000,0.2,20,100)
