
x <- as.Date(paste(2050:2018, "-12-31",sep=""))
