>library(quantmod)
>getQuote("ibm", src = "yahoo")
             Trade Time Last     Change   % Change   Open   High    Low  Volume
ibm 2018-05-01 16:01:34  145 0.03999329 0.02758918 144.65 145.02 143.47 3956770
