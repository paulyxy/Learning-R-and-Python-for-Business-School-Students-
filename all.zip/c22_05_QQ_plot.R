# normal Q-Q plot
set.seed(123)
x<-rnorm(1000)
qqnorm(x)

y<-runif(1000)
qqnorm(y)