
library(XLConnect)
path.package('XLConnect')