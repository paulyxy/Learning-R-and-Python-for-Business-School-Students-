rm(y)
load("c:/temp/test.RData")
head(y)

