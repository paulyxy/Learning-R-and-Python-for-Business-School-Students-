 x <- c("1jan1972","2jan1993","31mar1997","30jul2018")
 y <- as.Date(x, "%d%b%Y")
 y
