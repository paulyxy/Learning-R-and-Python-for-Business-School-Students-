

ascii_char <- function(n){ 
    rawToChar(as.raw(n)) 
}


