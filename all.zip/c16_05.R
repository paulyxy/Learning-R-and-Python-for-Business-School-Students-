 x<-1:100
 write.csv(x,'c:/temp/test.dat')