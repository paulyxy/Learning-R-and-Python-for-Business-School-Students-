
library(PortRisk)
data(SnP500Returns)
n<-5
base<-data.frame(rownames(SnP500Returns),SnP500Returns[,1:n])
names<-colnames(base)
colnames(base)<-c("DATE",names[2:n])
rownames(base)<-NULL
head(base,2)
base2<-na.omit(base)
cov(base2[,2:n])
                A           AA         AAPL         ABBV
A    1.901283e-04 5.555116e-05 8.946271e-06 5.131498e-05
AA   5.555116e-05 2.289971e-04 4.202145e-05 3.315804e-05
AAPL 8.946271e-06 4.202145e-05 3.293066e-04 1.017466e-05
ABBV 5.131498e-05 3.315804e-05 1.017466e-05 2.455843e-04
> 
