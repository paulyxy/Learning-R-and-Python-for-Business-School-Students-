
 x<-"2018.1"
 as.integer(x)+1
 y<-"2018.1"
 as.numeric(y)


