set.seed(123)
n<-5000
x<-mean(rnorm(n))
print(x)


