 days<- seq(as.Date("2017/1/1"),as.Date("2017/1/10"), "days")
 days
 w<-format(days, "%W")
 w
