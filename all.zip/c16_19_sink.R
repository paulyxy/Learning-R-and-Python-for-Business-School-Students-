 x<-1:10
 sink("c:/temp/test.txt") 
 x              # nothing shown on the screen
 print(x)       # again nothing shown
 sink()         # end of the sink operation



