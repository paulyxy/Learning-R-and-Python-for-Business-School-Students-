letterFreq<-function(text, letter){
    sum(charToRaw(text) == charToRaw(letter))

}
text<-"This is great!" 
text<-tolower(text)
x<-table(strsplit(text, "")) 
x
prop.table(x) 
letterFreq(text,"a")
letterFreq(text,"t")

