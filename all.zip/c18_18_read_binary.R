 in_f <- file("c:/temp/test.bin","rb")
 readBin(in_f, integer(), 4)


