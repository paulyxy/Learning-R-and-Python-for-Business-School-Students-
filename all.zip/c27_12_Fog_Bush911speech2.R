library(koRpus)
urlLink<-"http://canisius.edu/~yany/data/bush911.txt"
td = tempdir()
tf = tempfile(tmpdir=td, fileext=".txt")
download.file(urlLink, tf)
x<- tokenize(tf, lang="en")
y<- hyphen(x)
final<- readability(x,hyphen=y, index="all")
summary(final)






