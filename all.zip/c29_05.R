set.seed(123)
unique(as.integer(runif(100,1,27)))


x<-unique(as.integer(runif(1000,1,27)))
summary(x)



set.seed(123)
unique(as.integer(runif(100,1,27)))
