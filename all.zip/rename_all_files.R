# setwd("c://yan/teaching/Financial_modeling_using_R/code/tt/")


old<- list.files(pattern="c2.*")

 a<-gsub("^c2_","c3_",old)

b<-gsub(".txt$",".R",a)

new<-gsub(".R$",".R.txt",b)

# Copy from old files to new files

file.copy(from = old, to = new)

# Clear out the old files
file.remove(old)