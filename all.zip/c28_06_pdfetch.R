library(pdfetch)
x<-pdfetch_BLS(c("EIUIR","EIUIR100"), 2005, 2014)
head(x,2)

