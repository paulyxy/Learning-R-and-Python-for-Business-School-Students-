x<-"2018-2-1"
 weekdays(as.Date(x))
