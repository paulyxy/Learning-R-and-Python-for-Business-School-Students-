 x<-50:1
 write.table(x,file="c:/temp/test.txt")