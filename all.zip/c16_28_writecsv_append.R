
x<-1:10
write.csv(x,"c:/temp/test.csv")
y<-100:120
write.csv(y,"c:/temp/test.csv",append=TRUE)
