rm(list=ls())
ls()
load("c:/temp/test2")
ls()


[1] "x" "y"



