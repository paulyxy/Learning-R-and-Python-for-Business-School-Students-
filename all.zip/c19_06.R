x<-"this value is 1234.55"
gsub('[0-9]',"",x)