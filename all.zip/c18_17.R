x<-read.csv("c:/temp/ibm.csv",header=T)
y<-dim(x)
out.file<-file("c:/temp/ibm.bin","wb")
writeBin(y[2],out.file) # number of columns
writeBin(y[1],out.file) # number of obs
y<-as.integer(as.Date(x$Date))
writeBin(y,out.file)
writeBin(x$Open,out.file)
writeBin(x$High,out.file)
writeBin(x$Low,out.file)
writeBin(x$Close,out.file)
writeBin(x$Volume,out.file)
writeBin(x$Adj.Close,out.file)
close(out.file)

