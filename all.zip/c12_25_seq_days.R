

x<-seq(as.Date("2017/1/1"), as.Date("2018/12/31"), "days")
head(x)

d1<-seq(as.Date("2017/1/1"), as.Date("2018/12/31"), "months")
d2<-seq(as.Date("1951/1/1"), as.Date("1997/1/1"), "years")