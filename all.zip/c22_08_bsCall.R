call_f<-function(s,x,T,r,sigma){
     d1 = (log(s/x)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))
     d2 = d1-sigma*sqrt(T)
     s*pnorm(d1)-x*exp(-r*T)*pnorm(d2)
}