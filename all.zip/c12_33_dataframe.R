x<-2017
y<-"C"
z<-cbind(x,y)
z



