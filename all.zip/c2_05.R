library(timeDate)
 help(package=timeDate)
