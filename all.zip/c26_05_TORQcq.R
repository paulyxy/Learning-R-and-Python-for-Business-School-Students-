path<-"http://canisius.edu/~yany/RData/"
dataSet<-"TORQcq"
link<-paste(path,dataSet,".RData",sep='')
load(url(link))
 head(.TORQcq)
