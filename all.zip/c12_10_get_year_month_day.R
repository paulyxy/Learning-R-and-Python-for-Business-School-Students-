

x<-as.Date("2018-01-31","%Y-%m-%d")
#
format(x,"%Y")
format(x,"%y")
format(x,"%m")
format(x,"%d")