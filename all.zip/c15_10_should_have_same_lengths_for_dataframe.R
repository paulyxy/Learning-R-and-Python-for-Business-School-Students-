x<-1:6
y<-1:3
z<-data.frame(x,y)
z
