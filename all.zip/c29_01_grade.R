source("http://canisius.edu/~yany/codeyan")
encodeShift("I love you",1)

 encode5("eighty","great")


decode5('FZFZXZFZGYYY','great')
