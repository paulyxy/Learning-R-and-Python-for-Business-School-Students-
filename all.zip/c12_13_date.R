 x<-"2018-02-25"
 sub("-","",x) # replace the 1st "-" with nothing
 y<-"2018-12-31"
 gsub("-","",y) # replace all "-" with nothing
