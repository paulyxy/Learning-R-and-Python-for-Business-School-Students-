x<-2:5
y<-10:7
z<-cbind(x,y)
write(z,'c:/temp/test1.txt',ncolumns=2)
write(z, "c:/temp/test2.txt")
write(z, "c:\\temp\\test3.txt")
write.table(z,'c:/temp/text4.txt')
