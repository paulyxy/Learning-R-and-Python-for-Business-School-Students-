x<-1:9
y<-rev(x)
z<-cbind(x,y,x,x,x)
write.csv(z,"clipboard",quote=F,row.names=F)


