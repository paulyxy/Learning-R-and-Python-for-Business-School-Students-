x<-seq(-4,4,length=200)
y<-dnorm(x,mean=0,sd=1)
myName<-'Meaning of a density distribution'
plot(x,y,main=myName,lwd=2,type='l')
#
x0<-1
delta<-0.1
x<-seq(x0,x0+delta,,length=200)
y<-dnorm(x,mean=0,sd=1)
polygon(c(x0,x,x0+delta),c(0,y,0),col="red")
abline(h = 0, v = 0, col = "gray")


