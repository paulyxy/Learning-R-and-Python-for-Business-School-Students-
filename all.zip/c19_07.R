 path<-"http://canisius.edu/~yany/RData/retD50.RData"
 con<-url(path)
 load(con)
 dim(retD50)
 x<-subset(retD50,retD50$ticker=='IBM')
 dim(x)
