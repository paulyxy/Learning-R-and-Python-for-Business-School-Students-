ff<-tempfile()
x<-1:100
y<-matrix(x,20,5,byrow=T)
write.csv(y,ff)
rm(x,y)
z<-read.csv(ff)
head(z,2)
