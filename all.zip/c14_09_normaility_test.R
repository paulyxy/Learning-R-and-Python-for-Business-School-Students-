x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
n<-nrow(x)
p<-x[,6]
ret<-p[1:(n-1)]/p[2:n]-1
shapiro.test(ret)