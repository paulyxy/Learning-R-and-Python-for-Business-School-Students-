setwd("c:/temp")
inFile<-file("CT.BIN","rb")
x<-readBin(inFile,character(),size=4,n=1,endian="little")
substr(x,1,2)

