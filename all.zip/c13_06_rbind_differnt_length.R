 x<-c(1:5)
 y<-c(1:4)
 z<-rbind(x,y)
 z
