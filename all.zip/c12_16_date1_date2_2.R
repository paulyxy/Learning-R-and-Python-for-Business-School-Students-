



 days <- seq(as.Date("2017/1/1"),as.Date("2018/10/30"), "days")
 head(days)
 tail(days)

