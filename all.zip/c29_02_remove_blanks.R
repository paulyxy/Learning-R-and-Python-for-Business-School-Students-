
text<-" This is great "
gsub(' ', '',text)