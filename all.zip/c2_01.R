
# c4  page 

x<-read.csv("http://canisius.edu/~yany/ibm.csv",header=T)
 n<-nrow(x)
 ret<-NA
 for (i in 1:(n-1))
ret[i]<-(x[i+1,6]-x[i,6])/x[i,6]


x<-read.csv("http://canisius.edu/~yany/ibm.csv",header=T)
n<-nrow(x)
p<-x$Adj.Close
ret<-p[2:n]/p[1:(n-1)]-1


x<-read.csv("http://canisius.edu/~yany/ibm.csv",header=T)
n<-nrow(x)
p<-x$Adj.Close
ret<-p[2:n]/p[1:(n-1)]-1
d<-format(as.Date(x[,1]),"%Y-%m-%d")
ibm<-data.frame(d[2:n],x$Adj.Close[2:n],ret)
colnames(ibm)<-c('DATE','ADJ_PRICE','RET')


x<-read.csv("http://canisius.edu/~yany/ibm.csv",header=T)
d<-cbind("IBM",x)
a<-colnames(d)
a[1]<-"ticker"
colnames(d)<-a
d[1:2,]




 ticker<-"ibm"
 path<-"http://finance.google.com/finance/historical?q=NYSE:"
 a<-paste(path,ticker,"&output=csv",sep='')
 x<-read.csv(a)
 write.table(x,file='ibm.txt',quote=F,row.names=F)


tickers<-c("IBM","DELL")
for(stock in tickers){
    print(stock)
    path<-"http://finance.google.com/finance/historical?q=NYSE:"
    a<-paste(path,ticker,"&output=csv",sep='')
    x<-read.csv(a)
    print(x[1:2,])
}


beg<-as.Date("2016-1-1")
end<-as.Date("2016-3-31")
dd<-seq(beg,end,by=1) 
n<-length(dd)
set.seed(123)
ret<-runif(n,-0.02,0.03)
data<-data.frame(dd,ret)
colnames(data)<-c('DATE','RET')
yyyymm<-paste(format(data$DATE,"%Y"),format(data$DATE,"%m"),sep='')
logRet<-log(ret+1)
final<-data.frame(data,yyyymm,logRet)
logMonthly<-aggregate(logRet~yyyymm,data=final,FUN=sum)
retMonthly<-data.frame(logMonthly,exp(logMonthly$logRet)-1)
colnames(retMonthly)<-c("YYYYMM","logRet","RET")




#old one
beg<-as.Date("2000-02-01")
end<-as.Date("2000-05-31")
x<-seq(beg,end,by=1) # generate 365 calendar days
n<-length(x)
y<-as.Date("2000-02-01")
j=1
for(i in 1:(n-1)){
     today_month <-format(x[i], "%m")
     tomorrow_month <-format(x[i+1],"%m")
     if(today_month != tomorrow_month){
         y[j]<-x[i]
         j<-j+1
      }
}
if(format(y[j-1],"%m") !=format(x[n],"%m"))
y[j]<-x[n]












