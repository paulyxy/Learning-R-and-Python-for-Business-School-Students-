library(TTR)
x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv")
head(x,3)
diff<-momentum(x["Adj.Close"])
head(diff,3)
diff2<-momentum(x["Adj.Close"],2)
head(diff2,3)

