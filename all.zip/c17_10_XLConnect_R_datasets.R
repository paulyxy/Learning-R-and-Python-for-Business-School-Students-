library(XLConnect)
path<-path.package('XLConnect')

MetaData<-"/Meta"
path3<-paste(path,MetaData,sep='')
dir(path3)

