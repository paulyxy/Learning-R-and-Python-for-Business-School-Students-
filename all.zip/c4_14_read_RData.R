
dataSet<-"ff3monthly"
#
path<-"http://canisius.edu/~yany/RData/"
con<-paste(path,dataSet,".RData",sep='')
load(url(con))



