x<-read.table("c:/temp/test.txt")
x
colnames(x)<-c("ticker","date","ret")
write.table(x, "c:/temp/test3.txt",quote=F,row.names=F)


