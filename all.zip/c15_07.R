
 list1<-list(name="John",spouse="Mary",no.children=2,child.ages=c(14,9))
 list2<-list(name="Peter")
 list3<-list(name="Paul",spouse="Jen")
 k<-c(list1,list2,list3)
 length(k)

