 ddate<-20110131
 year<-as.integer(ddate/10000)
