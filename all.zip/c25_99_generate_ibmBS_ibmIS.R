x<-read.csv("c:/temp/ibmBS.csv",skip=2,stringsAsFactors =FALSE) 

xx=as.numeric(unlist(x[,2:4]))

dd<-dim(x)

bs<-matrix(xx,dd)
rownames(bs)<-x$Period.Ending

names<-gsub("X","",colnames(bs))
names2<-gsub("\\.","/",names)

colnames(bs)<-names2

.ibmBS<-bs
save(.ibmBS,file="c:/temp/ibmBS.RData")


colnames(bs)<-colnames(x)[2:4]

y<-read.csv("c:/temp/ibmIS.csv",skip=2,stringsAsFactors =FALSE) 
yy=as.numeric(unlist(y[,2:4]))
dd<-dim(y)
is<-matrix(yy,dd)
rownames(is)<-y[,1]
colnames(is)<-colnames(y)[2:4]


names<-gsub("X","",colnames(is))
names2<-gsub("\\.","/",names)

colnames(is)<-names2

.ibmIS<-is
save(.ibmIS,file="c:/temp/ibmIS.RData")




current_a<-bs[grep('Total Current Assets',rownames(bs)),] 
current_l<-bs[grep('Total Current Liabilities',rownames(bs)),] 
working_capital<-current_a/current_l



   NI<-    is[grep('Net Income',rownames(is)),]
   NI2<-    NI[nchar(rownames(NI))<=13,]
   Assets<-bs[grep('Total Assets',rownames(bs)),] 
   IBT<-   is[grep('^Income Before Tax',rownames(is)),]
   Interest<-   is[grep('Interest Expense(Income) - Net Operating',rownames(is)),]
   total_liab<-bs[grep('Total Liabilities',rownames(bs)),] 
   total_liab2<-total_liab[nchar(rownames(total_liab))<=20,] 
   sales<-is[grep('Total Revenue',rownames(is)),]

   loc<-paste("http://finance.yahoo.com/q?s=",ticker,"&ql=1",sep="")
   market_cap<-readHTMLTable(loc)[[2]][4,2]

   market_cap2<-gsub("[^0-9\\.]","",market_cap)

   x1<-working_capital/Assets
   x2<-NI2/Assets
   x3<-IBT/Assets
   x4<-as.numeric(market_cap2)*1000/total_liab2
   x5<-sales/Assets

   #return(0.012*x1+ 0.014*x2+ 0.033*x3+0.006*x4+0.999*x5)
   return(1.2*x1+ 1.4*x2+ 3.3*x3+0.6*x4+0.999*x5)
}


