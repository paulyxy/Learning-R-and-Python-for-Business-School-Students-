 x<-"Good"
 y<-"Morning!"
 paste(x,y,sep=" ") # sep is separator
