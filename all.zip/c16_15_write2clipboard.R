x<-1:9
y<-rev(x)
z<-cbind(x,y)
write.csv(z,"clipboard")
