# cumulative standard normal ditribution 

x<-seq(-3,3,0.25)
y<- pnorm(x)
title<-'Cumulative Standard Normal dist'
plot(x,y,main=title,type='b')
