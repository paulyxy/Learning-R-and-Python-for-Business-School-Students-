
loc<-"http://canisius.edu/~yany/RData/"
dataSet<-"AaaYieldMonthly"
link<-paste(loc,dataSet,".RData",sep='')
load(url(link)) 
head(.AaaYieldMonthly)


load("h://public_html/RData/AaaYieldMonthly.RData")
