> x <- c(NA, 6,2, 4, 6,NA)
> na.trim(x)
[1] 6 2 4 6