a<-c(4,-1,-3,1,4,1,-1,4,-1)
A<-matrix(a,3,3,byrow=T)
b<-c(5,8,8)
solve(A,b)

