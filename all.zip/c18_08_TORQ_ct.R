path<-"http://canisius.edu/~yany/RData/TORQct.RData"
load(url(path))
head(.TORQct)



