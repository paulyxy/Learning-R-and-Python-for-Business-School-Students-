

 #x<-read.table('c:/temp/ibm.csv',sep=',',header=T,stringsAsFactors =FALSE)
 x<-read.table('c:/temp/ibm.csv',sep=',',header=T)
 d<-data.frame(as.Date(x[,1],format="%Y-%m-%d"),x[,6])
 ibm<-data.frame(d[,1],d[,2])
 colnames(ibm)<-c('date','adj_price')
 head(x)
 head(ibm)

