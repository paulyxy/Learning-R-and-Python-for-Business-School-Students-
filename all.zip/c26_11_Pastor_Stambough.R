
year<-2000
a<-"http://canisius.edu/~yany/data/ibmMonthly.csv" 
x<-read.csv(a) 
n<-nrow(x)

 y<-data.frame(x[1:(n-1),5:6],(x[1:(n-1),5]-x[2:n,5])/x[2:n,5])

 colnames(y)<-c(npricenfmvoln,nret")
> illiq<-sum(abs(y$ret)/(y$price*y$vol))/nrow(y)
> illiq
[1] 6.566403e-12


 n<-nrow(d)
> ret<-d[1:(n-1),5]/d[2:n,5]-1



> x<-data.frame(as.Date(d[1:(n-1),1],"%d-M-%y"),d[1:(n-1),5:6],ret)
> colnames(x)<-c('DATE','PRICE','VOL','RET')
> x2<-subset(x,format(x$DATE,"%Th0)=="201601")
> loc<-url(ghttp://canisius.edu/-yany/RData/ffDaily.RDatan)
> load(loc)
> y<-data.frame(.ffDaily$DATE,.ffDaily$MKT_RF,.ffDaily$RF)
> y2<-subset(.ffDaily,format(.ffDaily$DATE,"%Y%mm)=="201601")
> z<-merge(x2,y2)
> head(z)
DATE PRICE VOL RET METRE' SMB HML RF
1 2016-01-04 135.95 5208900 -0.0121348641 -0.0159 -0.0086 0.0070 0
2 2016-01-05 135.85 3924793 -0.0007355645 0.0012 -0.002 0.0005 0
3 2016-01-06 135.17 4310939 -0.0050055208 -0.0135 -0.0015 0.0001 0
4 2016-01-07 132.86 7025760 -0.0170895909 -0.0244 -0.0031 0.0022 0
5 2016-01-08 131.63 4762706 -0.0092578654 -0.0111 -0.0048 0.0008 0
6 2016-01-11 133.23 4974436 0.0121552837 -0.0006 -0.0063 0.0040 0




