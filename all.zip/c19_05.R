x<-"Our company net income is $2.555."
gsub("[a-zA-Z]","",x)


z<-gsub(" *$","",y)
z