library(termstrc)
data(govbonds)
typeof(govbonds)
length(govbonds)


data(govbonds)
cf <- create_cashflows_matrix(govbonds[[1]])
dim(cf)
cf[1:5,1:5]



data(govbonds)
cf <- create_cashflows_matrix(govbonds[[1]])
m <- create_maturities_matrix(govbonds[[1]])
beta <- c(0.0511,-0.0124,-0.0303,2.5429)
price<-bond_prices(method="ns",beta,m,cf)$bond_prices
length(price)
head(price)


data(govbonds)
cf_p=create_cashflows_matrix(govbonds[[1]],include_price=TRUE)
m_p=create_maturities_matrix(govbonds[[1]],include_price=TRUE)
y<-bond_yields(cf_p,m_p)
dim(y)
head(y)

