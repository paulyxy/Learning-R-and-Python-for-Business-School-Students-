def dd(x):
    return 2*x
    

