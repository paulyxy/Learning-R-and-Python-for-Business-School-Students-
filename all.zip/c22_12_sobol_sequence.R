set.seed(12345)
x1<-rnorm(200)
y<-matrix(x1,100,2)
plot(y)


set.seed(12345)
library(fOptions)
x<-rnorm.sobol(n=100,dimension=2,scrambling=3)
plot(x,main="Sobol")

