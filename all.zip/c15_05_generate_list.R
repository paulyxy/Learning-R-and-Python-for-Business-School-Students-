

x<-list(name="Jeffrey",spouse="Mary",no.children=3,child.ages=c(9,5,1))
class(x)
