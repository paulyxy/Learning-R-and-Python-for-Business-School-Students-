
library(XLConnect)
x<- readWorksheetFromFile(demoExcelFile,sheet=1,header=FALSE,startCol=2, startRow=2,endCol=3,endRow=3)
