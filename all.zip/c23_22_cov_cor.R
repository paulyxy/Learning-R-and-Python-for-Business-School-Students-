library(PortRisk)
data(SnP500Returns)
base<-SnP500Returns
n<-4
x<-base[,1:n]
x2<-na.omit(x)
cov(x2)
cor(x2)

