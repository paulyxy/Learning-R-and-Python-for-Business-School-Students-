 set.seed(123)
 x<- rnorm(100)
 x[1:3]

