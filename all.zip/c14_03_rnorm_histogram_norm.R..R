
 set.seed(12345)
 x<-rnorm(1000)
 hist(x)
