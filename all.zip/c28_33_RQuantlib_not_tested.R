library(RQuantLib)
x<-AmericanOptionImpliedVolatility(type="call",value=11.10, underlying=100,
strike=100, dividendYield=0.01, riskFreeRate=0.03, maturity=0.5, volatility=0.4)
x[1]



