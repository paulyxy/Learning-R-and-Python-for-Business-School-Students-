ret_f<-function(x,name="RET"){
   n<-nrow(x)
   p<-x[,6]
   ret<-p[2:n]/p[1:(n-1)]-1
   final<-data.frame(x[2:n,1],ret)
   colnames(final)<-c("DATE",name)
   return(final)
}
x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
ibm<-ret_f(x,"RET_IBM")
y<-read.csv("http://canisius.edu/~yany/data/aaplDaily.csv",header=T)
aapl<-ret_f(y,"RET_AAPL")
final<-merge(ibm,aapl)


n<-nrow(final)
n1<-n-756
var.test(final$RET_IBM[n1:n],final$RET_AAPL[n1:n])
