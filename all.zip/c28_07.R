library(metafolio)
n<-3000 # number of simulation
w<-create_asset_weights(n_pop=6,n_sims=n,weight_lower_limit=0.001)
p<-monte_carlo_portfolios(weights_matrix=w,n_sims=n,mean_b=1000)
col_pal<-rev(gg_color_hue(6))
plot_efficient_portfolios(port_vals=p$port_vals,pal=col_pal,weights_matrix= w)


