library(TTR)
x <- getYahooData("IBM",19990404, 20050607)


