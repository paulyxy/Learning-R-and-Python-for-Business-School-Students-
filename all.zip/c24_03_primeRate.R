library(fImport)
x<-fredSeries("DPRIME") # DPRIME for daily prime rate
head(x)

