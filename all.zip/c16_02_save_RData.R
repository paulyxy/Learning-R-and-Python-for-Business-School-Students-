 x<-1:100
 set.seed(123)
 y<-rnorm(200)
 head(y,2)
 save(x,y,file="c:/temp/test.RData")