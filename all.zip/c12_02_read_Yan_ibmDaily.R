d<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
 head(d)
