out_f<- file("c:/temp/test.bin","wb")
x<--10:10
writeBin(x, out_f)
writeBin(pi,out_f, endian="little")
writeBin(pi, out_f, size=4)
close(out_f)



