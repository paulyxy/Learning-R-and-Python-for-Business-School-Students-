require(PerformanceAnalytics)
data(managers)
stock<- managers[, "HAM2", drop=FALSE]
mkt<- managers[, "SP500 TR",drop=FALSE]
rf<- managers[, "US 3m TR",drop=FALSE]
CAPM.beta(stock,mkt,rf)

CAPM.beta.bull(stock,mkt,rf)
CAPM.beta.bear(stock,mkt,rf)



