x<-seq(-4,4,0.25)
y<-dnorm(x)
plot(x,y,main='Standard Normal Density Distribution',type='l')



