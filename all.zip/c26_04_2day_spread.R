x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
H<-x$High
L<-x$Low
n<-nrow(x)
s<-NA
for(i in 2:n){
  beta<-log(H[i]/L[i])^2
  H2<-max(H[i+1],H[i])
  L2<-min(L[i+1],L[i])
  gamma<-log(H2/L2)^2
  t<-3-2*sqrt(2)
  alpha<-(sqrt(2*beta)-sqrt(beta))/t- sqrt(gamma/t)
  s[i-1]<-(2*exp(alpha)-1)/(1+exp(alpha))
}
s2<-s[is.na(s)==F]
print(mean(s2))


