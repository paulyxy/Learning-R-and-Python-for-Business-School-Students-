
set.seed(123)
x <- rnorm(500, mean = 0, sd =0.5)
y <- rnorm(1000,mean = 0.5,sd =0.2)
var.test(x,y)


