

inFile<-file("c:/temp/CT.BIN","rb")
seek(inFile,31)
seek(inFile)
x<-readBin(inFile,character(),size=4,n=1,endian="little")
substr(x,2,3)

