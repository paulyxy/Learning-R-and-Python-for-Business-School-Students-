library(lmtest)
d<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
p<-d[,6]
n<-nrow(d)
ret<-p[2:n]/p[1:(n-1)]-1
m<-as.integer(length(ret)/2)
x<-rep(c(-1,1),m)
dwtest(ret[1:(2*m)]~x)


Durbin-Watson test
data: ret[1:(2 * m)] ~ x
DW = 2.0314, p-value = 0.9658
alternative hypothesis: true autocorrelation is greater than 0