
path<-"http://canisius.edu/~yany/RData/"
dataSet<-"termStructure"
link<-paste(path,dataSet,".RData",sep='')
load(url(link))
head(.termStructure)

