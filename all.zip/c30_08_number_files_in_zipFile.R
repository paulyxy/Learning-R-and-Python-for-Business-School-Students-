infile<-"c:/temp/new.zip"
t<-paste("c:/progra~1/7-Zip/7z l ",infile,seq="")
x<-readLines(pipe(t))
n<-length(x)
out<-NA
for(i in 1:n){
    if(length(grep("\\.csv",x[i]))!=0)out<-rbind(out,x[i])
}
out2<-subset(out,!is.na(out[,1]))
length(out2)
