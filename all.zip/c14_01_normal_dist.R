x<-seq(-4,4,length=500)
y<-1/sqrt(2*pi)*exp(-x^2/2)
 plot(x,y,type="l",lwd=2,col="red")


# 'l' is the lower case letter of L
# lwd: line widths for the axis line
# and the tick marks