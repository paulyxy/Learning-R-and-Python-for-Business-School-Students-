library(lmtest)
ma<- rnorm(100) # rho=0 (white noise)
x <- rep(c(-1,1), 50)
head(x,10)
y1<- 1 + x + ma
dwtest(y1 ~ x)

