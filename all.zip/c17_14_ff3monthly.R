
 library(WriteXLS)
 path<-"http://canisius.edu/~yany/RData/ff3monthly.RData"
 con<-url(path)
 load(con)
 head(.ff3monthly,2)
 WriteXLS(.ff3monthly, "c:/temp/ff3.xlsx",AdjWidth = TRUE, BoldHeaderRow = TRUE, row.names = TRUE)


