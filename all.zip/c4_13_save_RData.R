> ticker<-"IBM"
> path<-"http://finance.google.com/finance/historical?q=NYSE:"
> a<-paste(path,ticker,"&output=csv",sep='')
> x<-read.csv(a)
> save(x,file='ibm.RData')
