write.table2<-function(x, file = "", append = FALSE, quote =F, sep = " ",
       eol = "\n", na = "NA", dec = ".", row.names = F,
       col.names = TRUE, qmethod = c("escape", "double"),
       fileEncoding = ""){

  #
  write.table(x, file, append, quote, sep,eol,na, dec,
    row.names,col.names, qmethod,fileEncoding)
  #
}
