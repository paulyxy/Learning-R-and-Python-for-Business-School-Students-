# diagonal matrix 
x<-diag(5)