

con<-url("http://canisius.edu/~yany/RData/marketCap.RData")
load(con)

head(.marketCap)
