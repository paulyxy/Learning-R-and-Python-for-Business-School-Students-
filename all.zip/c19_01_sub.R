 a<-"Excellent"
 sub("l","2",a) 
