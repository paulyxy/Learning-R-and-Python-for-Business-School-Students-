 pdf("c:/temp/picture.pdf")
 plot(sin,-2*pi,2*pi)
 dev.off()