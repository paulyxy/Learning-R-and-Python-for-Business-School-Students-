library(fExoticOptions)
GeometricAverageRateOption(TypeFlag="p",S = 80,X = 85,Time = 0.25, r =
0.05, b = 0.08,sigma= 0.2)


