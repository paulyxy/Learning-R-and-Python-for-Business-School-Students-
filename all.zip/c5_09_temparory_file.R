

url<-"http://datayyy.com/data_csv/ffc4Monthly.csv"
outFile<-'c://temp/ffc4Monthly.csv'
download.file(url,outFile, mode = "w")

 download.file(url,outFile, mode = "w",quiet=T)




url<-"http://datayyy.com/data_csv/ffc4Monthly.csv"
ff<-tempfile()
download.file(url,ff, mode = "w",quiet=T)
x<-read.csv(ff)
head(x)






C:\\Users\\pauly\\AppData\\Local\\Temp\\Rtmps9FEQo\\file30843cdc272d

C:\Users\pauly\AppData\Local\Temp\Rtmps9FEQo\file30843cdc272d

