in.file<-file("c:/temp/test.bin","rb") 
readBin(in.file,integer(),size=4,endian='little')
readBin(in.file,integer(),size=4,endian='little')
close(in.file)



