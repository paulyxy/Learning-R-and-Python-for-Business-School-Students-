

con<-url("http://canisius.edu/~yany/RData/ff3monthly.RData")
load(con, verbose = FALSE)

head(.ff3monthly)
