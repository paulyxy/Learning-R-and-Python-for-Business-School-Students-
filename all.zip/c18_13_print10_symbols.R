
inFile<-file("c:/temp/CT.BIN","rb")

for(i in 1:10){
   n<-(i-1)*31+12
   seek(inFile,n)
   x<-readBin(inFile,character(),n=1,endian="little")
   y<-substr(x,1,3)
   cat(y,"\n")
}
