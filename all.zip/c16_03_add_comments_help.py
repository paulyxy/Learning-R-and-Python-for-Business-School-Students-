def pv_f(fv,r,n):
    """Objective: calculate present value of one future value
            fv  : future value
            r   : period rate
            n   : the number of periods  
                          fv
        Formula     pv= ------
                        (1+r)^n
      Example #1 >>> pv_f(100,0.1,1)
                     90.9090909090909
      Example #2:  pv_f(r=0.1,n=1,fv=100)
                  90.9090909090909
    """
    return fv/(1+r)**n







