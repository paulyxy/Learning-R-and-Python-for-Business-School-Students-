library(koRpus)
urlLink<-"http://canisius.edu/~yany/data/bush911.txt"
td = tempdir()
tf = tempfile(tmpdir=td, fileext=".txt")
download.file(urlLink, tf)
x<- tokenize(tf, lang="en")
FOG(x)





