


x <-read.table('c:/temp/ibm.csv',sep=',',header=T)

x[2,1]