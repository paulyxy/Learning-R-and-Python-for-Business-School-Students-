 x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
 n<-nrow(x)
 p<-x$Adj.Close
 ret<-p[2:n]/p[1:(n-1)]-1
 dates<-as.Date(x[2:n,1])
 d<-data.frame(dates,ret)
 colnames(d)<-c("date","ret")
 data<-subset(d,weekdays(d[,1])=="Monday")



