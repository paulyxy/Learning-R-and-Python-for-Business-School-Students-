

library(readxl)
data <- readxl_example("datasets.xlsx")
x<-read_excel(data)
dim(x)
head(x,2)
tail(x,2)


