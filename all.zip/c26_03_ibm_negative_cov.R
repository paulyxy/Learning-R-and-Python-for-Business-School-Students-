
a<-"http://canisius.edu/~yany/data/ibmDaily.csv" 
x<-read.csv(a) 
n1<-nrow(x)
p<-x$Adj.Close[(n1-500):n1]
deltaP<-diff(p)
n<-length(deltaP)
covP<-cov(deltaP[1:(n-1)],deltaP[2:n])
covP
if(covP>0){
   s<--2*sqrt(covP)
}else{
   s<-2*sqrt(-covP)
}
print(s)


