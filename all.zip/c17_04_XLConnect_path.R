library(XLConnect)
path.package('XLConnect', quiet = FALSE)


