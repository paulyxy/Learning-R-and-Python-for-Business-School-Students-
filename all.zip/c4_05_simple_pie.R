


grades <- c(9,10,14, 16,8)

nameA<-"grade:A (excellent)"
nameAminus<-"grade:A- (good)"
nameC<-"grade: C (not good)"
pct<-round(grades/sum(grades)*100)
names <- c(nameA,nameAminus,"B+", "B",nameC)
names<-paste(names,pct)
names<-paste(names,"%",sep='')

pie(grades, labels = names, main="Pie Chart of grades")




