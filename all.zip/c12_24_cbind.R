x<-2017
y<-2018
cbind(x,y)
x<-2017
y<-"2018"
cbind(x,y)
