library(fImport)
data(amexListing)
head(amexListing)



