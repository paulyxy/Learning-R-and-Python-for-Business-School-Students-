x <-1:50
y<-matrix(x,10,5)
temp <- tempfile()
write.table(y, temp,sep='\t')
z<-read.delim(temp)

head(y,2)
head(z,2)



