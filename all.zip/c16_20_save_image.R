

pv<-100
r<-0.1
n<-5
pv_f<-function(fv,r,n)fv/(1+r)^n
fv_f<-function(pv,r,n)pv*(1+r)^n
pv_perptuity<-function(c,r)c/r
save.image("c:/temp/myJob.RData")


rm(list=ls())
ls()
load("c:/temp/myJob.RData")
ls()

