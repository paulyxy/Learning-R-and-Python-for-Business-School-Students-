x<-c(1,2,3)
y<-c("a","b","c")
z<-as.matrix(rbind(x,y))
is.matrix(z)
z


 