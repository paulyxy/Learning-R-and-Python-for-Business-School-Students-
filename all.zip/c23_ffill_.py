# -*- coding:no utf-8 -*-
"""
Created on Fri Nov 20 07:46:38 2020

@author: pyan
"""

import pandas as pd
df = pd.DataFrame({
    'A': [1, None, None, None], 
    'B': [3, 2, None, None], 
    'C': [4, None, 3, None], 
    'D': [18, None, None, 20]})
#
a=df.apply(lambda series: series.loc[:series.last_valid_index()].ffill())

