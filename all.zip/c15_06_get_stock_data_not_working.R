

 library(XML)
 ticker<-"IMB"
 type<-"financials/balance-sheet"
 path<-"https://www.marketwatch.com/investing/stock/"
 web<-paste(path,ticker,"/",type,sep='')
 x<-readHTMLTable(web)



  web<-"https://www.inflationdata.com/Inflation/Consumer_Price_Index/HistoricalCPI.aspx"

