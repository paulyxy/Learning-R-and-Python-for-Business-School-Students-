ST_f<-function(S,r,T,sigma){ 
     temp1<-(r-0.5*sigma*sigma)*T
     temp2<-sigma*rnorm(1)*sqrt(T)
     final<-S*exp(temp1+temp2)
     return(final)
}

