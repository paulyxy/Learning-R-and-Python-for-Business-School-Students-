

inFile<-file("c:/temp/CT.BIN","rb")
x<-readBin(inFile,character(),n=1,endian="little")
EX<-substr(x,2,3)
G127<-readBin(inFile,integer(),size=2,n=1,endian="little")
seek(inFile,4)
price<-readBin(inFile,integer(),size=4,n=1,endian="little")/256.0
siz<-readBin(inFile,"int",n=1,endian="little")
k<-readBin(inFile,"character",size=3,n=1,endian="little")
symbol<-substr(k,1,3)
seek(inFile,15)
TDATE<-readBin(inFile,"int",size=4,n=1,endian="little")
TSEQ<-readBin(inFile,"int",n=1,endian="little")
TIM<-readBin(inFile,"int",n=1,endian="little")
dummy<-readBin(inFile,"int",n=1,endian="little")
close(inFile)





