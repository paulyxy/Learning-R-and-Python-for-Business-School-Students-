

ascii_char <- function(n){ 
    rawToChar(as.raw(n)) 
}
for(i in 1:255){
   cat(ascii_char(i))
   if(i%%40==0)cat("\n")
}




