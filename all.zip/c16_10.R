

x<-1:50
y<-rnorm(500)
save(x,y,file="c:/temp/test.RData")

