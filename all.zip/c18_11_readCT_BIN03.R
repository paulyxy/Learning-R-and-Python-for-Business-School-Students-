setwd("c:/temp")
inFile<-file("CT.BIN","rb")

seek(inFile,3)
x<-readBin(inFile,integer(),size=4,n=1,endian="little")




