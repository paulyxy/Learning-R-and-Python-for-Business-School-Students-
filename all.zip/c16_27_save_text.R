 x<-1:100
 write.table(x,file="c:/temp/test.txt",quote=F,row.names=F)