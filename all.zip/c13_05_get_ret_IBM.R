

 x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv",header=T)
 head(x,2)
 p<-x$Adj.Close
 n<-length(p)
 ret<-p[2:n]/p[1:(n-1)]-1
 final<-data.frame(x[2:n,-4:-2],ret)



