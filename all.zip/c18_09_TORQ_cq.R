path<-"http://canisius.edu/~yany/RData/"
dataSet<-"TORQcq"
inFile<-paste(path,dataSet,".RData",sep='')
#
load(url(inFile))
head(.TORQcq)





