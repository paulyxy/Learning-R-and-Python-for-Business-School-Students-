n<-100
x<-runif(n) # generate random numbers
y<-runif(n) # generate random numbers
z<-0*(1:n)
for(i in 1:n){
   if( (x[i]-0.5)^2 + (y[i]-0.5)^2<=0.5^2) z[i]=4;
}
print(mean(z))