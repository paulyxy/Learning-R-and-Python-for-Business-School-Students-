library(fAsianOptions)

ZhangAsianOption(TypeFlag = "c",S = 100, X = 100, Time = 1,r = 0.09, sigma =
+ 0.30, table = NA, correction = TRUE, nint = 800,eps = 1.0e-8, dt = 1.0e-10)

