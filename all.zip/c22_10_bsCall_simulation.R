 bsCall(40,42,0.5,0.1,0.2)

 set.seed(212)
 bsCallSimulation(40,42,0.5,0.1,0.2,5000)

