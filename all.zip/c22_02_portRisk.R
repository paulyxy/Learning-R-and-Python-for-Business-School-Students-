library(PortRisk)
data(SnP500List)
head(SnP500List)
n<-nrow(SnP500List)
set.seed(12345)
m<-20
x<-unique(as.integer(runif(m,1,n)))
x
y<-SnP500List[x,]
y






