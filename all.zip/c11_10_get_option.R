
library(quantmod)
x<-getOptionChain("AAPL")

