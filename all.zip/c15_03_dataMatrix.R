

a<-1:3
b<-letters[2:4]
c<-seq(as.Date("2004-01-01"), by = "month",len = 3)
x <- data.frame(a, b, c, stringsAsFactors = TRUE)