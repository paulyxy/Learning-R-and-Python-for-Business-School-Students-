library(fImport)
y<-fredSeries("MPRIME")
head(y)
