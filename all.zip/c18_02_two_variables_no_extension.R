x<-2:100
y<-c("this", "is"," a test")
save(x,y,file="c:/temp/test2")
