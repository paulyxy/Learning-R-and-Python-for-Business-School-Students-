 set.seed(123)
 x<-rnorm(50)
 y<-x[1:10] 
 y



