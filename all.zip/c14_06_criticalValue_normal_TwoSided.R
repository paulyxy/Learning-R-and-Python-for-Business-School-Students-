
# critical value of Normal distribution 
# 2-sided 

alpha<-0.05
qnorm(1-alpha/2) 

#    [1] 1.959964


