library(koRpus)
inFile<-"c:/temp/obama2008.txt"
x<- tokenize(inFile, lang="en")
FOG(x)






