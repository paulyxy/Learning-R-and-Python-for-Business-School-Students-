 x<-1:10
 save(x,file="c:/temp/test.Rdata")