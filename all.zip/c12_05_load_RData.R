 rm(x)
 load("c:/test_R/test.Rdata") 
 head(x)