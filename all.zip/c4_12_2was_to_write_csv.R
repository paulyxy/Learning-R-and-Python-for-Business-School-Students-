> write.table(x,file='c.csv',sep=',',quote=F,row.names=F)
> write.csv(x,file='c.csv',quote=F,row.names=F)
