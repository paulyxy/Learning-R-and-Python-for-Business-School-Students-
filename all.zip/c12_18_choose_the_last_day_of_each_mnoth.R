x<-seq(as.Date("2017/1/1"),as.Date("2018/12/31"), "days")

 n<-length(x) # note: days is the keyword
 m<-format(x,"%m") # generate a month variable
 y<-data.frame(x,m)
 y2<-subset(y,y[1:(n-1),2]!=y[2:n,2])
 y2[1:5,]
