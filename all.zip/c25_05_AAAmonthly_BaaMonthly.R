path<-"http://canisius.edu/~yany/RData/"
data1<-"AaaYieldMonthly"
data2<-"BaaMonthly"
link1<-paste(path,data1,".RData",sep='')
link2<-paste(path,data2,".RData",sep='')
load(url(link1))
load(url(link2))



