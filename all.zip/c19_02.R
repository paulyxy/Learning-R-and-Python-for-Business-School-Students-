 a<-"Excellent"
 gsub("l","2",a) 
