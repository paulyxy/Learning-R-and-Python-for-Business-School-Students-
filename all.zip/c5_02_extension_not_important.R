 set.seed(123)
 n<-100
 x<-rnorm(n)
 head(x)
 save(x,file="c:/temp/test")
 rm(x)
 load("c:/temp/test")
 head(x)


