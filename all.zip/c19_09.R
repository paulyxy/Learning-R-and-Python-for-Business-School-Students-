
ascii_number<- function(x) { 
    strtoi(charToRaw(x),16L) 
}


