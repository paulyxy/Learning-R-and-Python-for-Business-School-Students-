 x<-as.Date("2018-02-01",format="%Y-%m-%d")
 y<-as.integer(format(x, "%Y"))
 data<-cbind(x,y)
 data
 x<-as.Date("2018-02-01",format="%Y-%m-%d")
 y<-as.integer(format(x,"%Y"))
 data2<-data.frame(x,y)
 data2
