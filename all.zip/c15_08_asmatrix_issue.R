x<-c(20178,0.1,2018,0.12)
y<-matrix(x,2,2,byrow=T)
z<-data.frame("abc",y)
colnames(z)<-c("ticker","year","ret")
a<-as.matrix(z)
a



