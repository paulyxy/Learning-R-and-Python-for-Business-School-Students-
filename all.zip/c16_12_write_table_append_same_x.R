
x<-1:10
write.table(x,"c:/temp/test.txt")
x<-100:120
write.table(y,"c:/temp/test.txt",append=TRUE)