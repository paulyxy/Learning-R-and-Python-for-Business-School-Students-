code_sub<-function(message){
   set.seed(123)
   x<-unique(as.integer(runif(100,1,27)))
   y<-letters[x]
   text<-gsub("[^a-z]",'',tolower(message)) # remove non-letter
   coded_text<-''
   for(i in 1:nchar(text)){
      for(j in 1:26){
          if(letters[j]==substr(text,i,i)){
             coded_text<-paste(coded_text,y[j],'',sep='')
             break
          }
      }
   }
   return(coded_text)
}


code_sub("I love you")